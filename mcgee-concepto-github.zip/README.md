# MGI McGee Ingeniería · concepto de diseño

Boceto de una página web. **No es el sitio oficial** de la empresa.

- Fotos y logo: tomados del Instagram público de @mcgeeingenieria, solo para este boceto.
- Es un concepto de diseño: no está en producción.
- Mantener el repositorio **privado** mientras no haya acuerdo y pago del anticipo.

Para verlo: abrir `index.html`. Con GitHub Pages: Settings → Pages → rama `main`, carpeta `/ (root)`.
